﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConverterApp
{
        public partial class frm_Main : Form
    {

        public string[] ConversionList = new string[5]; //Declare array and size
        public int counter = 0; //Create integer for conversion limit
        
        public frm_Main()
        {
            InitializeComponent();
            txt_UnitOfMeasure.Focus(); //Focuses user input box
        }

        // Global Variables and Constants
        double dbl_UofM, dbl_Convert;

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit(); //Closes application
        }

        private void btn_CM_to_Inches_Click(object sender, EventArgs e)
        {
            if (counter < 5) //Check number of conversions
            {
                const double Cm_to_Inch = 0.393701; //Conversion value

                if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM)) //Validate user entry and convert to a double
                {
                    MessageBox.Show("A numeric value must be entered. Please re-enter the value."); //Displays error message
                    txt_UnitOfMeasure.Clear(); //Clears textbox
                    txt_UnitOfMeasure.Focus(); //Focuses on textbox
                    lbl_Answer.Text = ""; //Clears answer label
                }
                else
                {
                    dbl_Convert = dbl_UofM * Cm_to_Inch; //Converts user's input
                    lbl_Answer.Text = txt_UnitOfMeasure.Text + " Centimetres is converted to " + dbl_Convert + " Inches."; //Displays input and conversion
                    ConversionList[counter] = lbl_Answer.Text; //Adds conversion to array
                    counter++;
                    txt_UnitOfMeasure.Focus(); //Focuses textbox
                    txt_UnitOfMeasure.SelectAll(); //Highlights textbox
                }
            }
            else
            {
                MessageBox.Show("You have used your limit of 5 conversions."); //Limit message
                lbl_Answer.Text = ""; //Clears label
                txt_ConversionList.Clear(); //Clears textbox
                for (int displaycounter = 0; displaycounter < 5; displaycounter++) //For loop to display the list of conversions
                    txt_ConversionList.AppendText(ConversionList[displaycounter] + Environment.NewLine); //Write to the textbox
            }
        }

        private void btn_M_to_Feet_Click(object sender, EventArgs e)
        {
            if (counter < 5) //Check number of conversions
            {
                const double M_to_Feet = 3.28084; //Conversion value

                if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM)) //Validates user entry and converts to a double
                {
                    MessageBox.Show("A numeric value must be entered. Please re-enter the value."); //Displays error message
                    txt_UnitOfMeasure.Clear(); //Clears textbox
                    txt_UnitOfMeasure.Focus(); //Focuses on textbox
                    lbl_Answer.Text = ""; //Clears answer label
                }
                else
                {
                    dbl_Convert = dbl_UofM * M_to_Feet; //Converts user input
                    lbl_Answer.Text = txt_UnitOfMeasure.Text + " Metres is converted to " + dbl_Convert + " Feet."; //Displays input and conversion
                    ConversionList[counter] = lbl_Answer.Text; //Adds conversion to array
                    counter++;
                    txt_UnitOfMeasure.Focus(); //Focuses on textbox
                    txt_UnitOfMeasure.SelectAll(); //Highlights textbox
                }
            }
            else
            {
                MessageBox.Show("You have used your limit of 5 conversions."); //Limit message
                lbl_Answer.Text = ""; //Clears label
                txt_ConversionList.Clear(); //Clears textbox
                for (int displaycounter = 0; displaycounter < 5; displaycounter++) //For loop to display the list of conversions
                    txt_ConversionList.AppendText(ConversionList[displaycounter] + Environment.NewLine); //Write to the textbox
            }
        }

        private void btn_C_to_Fahrenheit_Click(object sender, EventArgs e)
        {
        if (counter < 5) //Check number of conversions
            {
            const double C_to_F_Multiplication = 1.8, C_to_F_Addition = 32; //Conversion values

            if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM)) //Validates user entry and converts to a double
                {
                MessageBox.Show("A numeric value must be entered. Please re-enter the value."); //Displays error message
                txt_UnitOfMeasure.Clear(); //Clears textbox
                txt_UnitOfMeasure.Focus(); //Focus' on textbox
                lbl_Answer.Text = ""; //Clears answer label
            }
            else
            {
                dbl_Convert = dbl_UofM * C_to_F_Multiplication + C_to_F_Addition; //Converts user input
                lbl_Answer.Text = txt_UnitOfMeasure.Text + " ° Celsius is converted to " + dbl_Convert + " ° Fahrenheit."; //Displays input and conversion
                ConversionList[counter] = lbl_Answer.Text; //Adds conversion to array
                counter++;
                txt_UnitOfMeasure.Focus(); //Focuses textbox
                txt_UnitOfMeasure.SelectAll(); //Highlight textbox
            }
        }
        else
        {
            MessageBox.Show("You have used your limit of 5 conversions."); //Limit message
            lbl_Answer.Text = ""; //Clears label
            txt_ConversionList.Clear(); //Clears textbox
            for (int displaycounter = 0; displaycounter < 5; displaycounter++) //For loop to display conversions
                txt_ConversionList.AppendText(ConversionList[displaycounter] + Environment.NewLine); //Write to textbox
            }
    }

        private void btn_C_to_Feet_Click(object sender, EventArgs e)
        {
            if (counter < 5) //Check number of conversions
            {
                const double C_to_Feet = 0.0328084; //Conversion value

                // validate user entry and convert to a double

                if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM)) //Validates user entry and converts to a double
                {
                    MessageBox.Show("A numeric value must be entered. Please re-enter the value."); //Displays Error message
                    txt_UnitOfMeasure.Clear(); //Clears textbox
                    txt_UnitOfMeasure.Focus(); //Focus' on textbox
                    lbl_Answer.Text = ""; //Clears answer label
                }
                else
                {
                    dbl_Convert = dbl_UofM * C_to_Feet; //Converts user input
                    lbl_Answer.Text = txt_UnitOfMeasure.Text + " Centimetres is converted to " + dbl_Convert + " Feet."; //Displays Conversion
                    ConversionList[counter] = lbl_Answer.Text; //Adds conversion to array
                    counter++;
                    txt_UnitOfMeasure.Focus(); //Focuses textbox
                    txt_UnitOfMeasure.SelectAll(); //Highlights textbox
                }
            }
            else
            {
                MessageBox.Show("You have used your limit of 5 conversions."); //Limit message
                lbl_Answer.Text = ""; //Clear label
                txt_ConversionList.Clear(); //Clear textbox
                for (int displaycounter = 0; displaycounter < 5; displaycounter++) //For loop for displaying conversions
                    txt_ConversionList.AppendText(ConversionList[displaycounter] + Environment.NewLine); //Write conversions to textbox
            }
        }
                
        private void btn_K_to_Miles_Click(object sender, EventArgs e)
        {
            if (counter < 5) //Check number of conversions
            {
                const double K_to_Mile = 0.621371; //Conversion value

                if (!double.TryParse(txt_UnitOfMeasure.Text, out dbl_UofM)) // validate user entry and convert to a double
                {
                    MessageBox.Show("A numeric value must be entered. Please re-enter the value.");
                    txt_UnitOfMeasure.Clear(); //Clears textbox
                    txt_UnitOfMeasure.Focus(); //Focus' on textbox
                    lbl_Answer.Text = ""; //Clears answer label
                }
                else
                {
                    dbl_Convert = dbl_UofM * K_to_Mile; //Converts input
                    lbl_Answer.Text = txt_UnitOfMeasure.Text + " Kilometres is converted to " + dbl_Convert + " Miles."; //Display conversion
                    ConversionList[counter] = lbl_Answer.Text; //Adds conversion to array
                    counter++;
                    txt_UnitOfMeasure.Focus(); //Focuses textbox
                    txt_UnitOfMeasure.SelectAll(); //Highlights textbox
                }
            }
            else
            {
                MessageBox.Show("You have used your limit of 5 conversions."); //Limit message
                lbl_Answer.Text = ""; //Clear label
                txt_ConversionList.Clear(); //Clear textbox
                for (int displaycounter = 0; displaycounter < 5; displaycounter++) //For loop to display conversions
                    txt_ConversionList.AppendText(ConversionList[displaycounter] + Environment.NewLine); //Writes to the textbox
            }
        }

        
        private void btn_Display_Conversions_Click(object sender, EventArgs e)
        {
            lbl_Answer.Text = ""; //Clears label
            txt_ConversionList.Clear(); //Clears textbox
            for (int displaycounter = 0; displaycounter < 5; displaycounter++) //For loop
                txt_ConversionList.AppendText(ConversionList[displaycounter] + Environment.NewLine); //Writes to textbox
        }

    }
}
